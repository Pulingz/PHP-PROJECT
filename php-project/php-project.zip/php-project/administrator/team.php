<!-- Bootstrap core CSS -->
  <!-- <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet"> -->
  <div class="card text-white bg-dark mb-3" style="max-width: 18rem;">
    <a href="#" class="item"><img class="card-img-top" src="hasil-upload/hacker.jpeg" alt="Card image cap">
    <div class="card-body">
      <h3 class="card-title1">Puling,18</h3>
      <h4 class="card-title2">Chief Developer</h4>
      <h5 class="card-title3">Universitas UIN Jakarta,Tanggerang</h5>
      <h6 class="card-title4">| Ahmad Faiz |</h6>
     <p class="card-text"><a href="https://www.facebook.com/profile.php?id=100009493614474" target="_blank"><i class="fab fa-facebook-square fa-2x"></i></a><a href="https://twitter.com/ahmadfaiz927" target="_blank"><i class="fab fa-twitter-square fa-2x"></i></a><a href="https://instagram.com/ahmad.faiz927/" target="_blank"><i class="fab fa-instagram-square fa-2x"></i></a><a href="https://line.me/ti/p/Ahmad%20Faiz" target="_blank"><i class="fab fa-line fa-2x"></i></a><a href="https://api.whatsapp.com/send/?phone=6281293036735&text&app_absent=0" target="_blank"><i class="fab fa-whatsapp-square fa-2x"></i></a></p></a>
    </div>
  </div>
        
    <!-- <script src="../assets/dist/js/bootstrap.bundle.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
